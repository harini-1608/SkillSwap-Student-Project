# SkillSwap - Skill Exchange Platform

SkillSwap is a full-stack web application built with Python Flask that allows users to exchange skills without monetary transactions. It connects people who want to teach what they know with those who want to learn something new.

---

## 🚀 Features

* User Authentication (Register, Login, Logout)
* Profile Management (Bio, Skills, Location)
* Skill Management (Add, Edit, Delete)
* Smart Skill Matching System
* Exchange Request System (Send, Accept, Reject)
* Dashboard with activity tracking
* Search and filter users by skills
* Responsive UI using Bootstrap

---

## 🛠️ Tech Stack

* **Backend:** Python, Flask, SQLAlchemy
* **Database:** SQLite
* **Frontend:** HTML, CSS (Bootstrap), JavaScript
* **Libraries:** Flask-Login, Flask-Bcrypt, scikit-learn 

---

## ⚙️ How to Run the Project

### 1. Clone or Download the Project

Download ZIP or clone using Git:

```
git clone https://github.com/NirmitiB/Skill-Exchange-Platform.git
```

---

### 2. Navigate to Project Folder

```
cd Skill-Exchange-Platform
```

---

### 3. Install Dependencies

```
pip install -r requirements.txt
```

---

### 4. Seed the Database

This step adds sample users and skills for testing:

```
python seed.py
```

---

### 5. Run the Application

```
python run.py
```

---

### 6. Open in Browser

Go to:

```
http://127.0.0.1:5000/
```

---

## 📁 Project Structure

* `app/` – Main application

  * `models/` – Database models
  * `routes/` – Application routes
  * `templates/` – HTML files
  * `static/` – CSS, JS, images
* `config.py` – Configuration settings
* `run.py` – Application entry point
* `seed.py` – Dummy data script
* `requirements.txt` – Dependencies

---

## 📌 Notes

* Make sure Python 3 is installed
* Internet may be required for some features
* Database will be created automatically if not present

---
## 📊 Running the Jupyter Notebook

The project also includes `Skillswap_Project.ipynb`, which analyses student skills and generates skill-match recommendations using Python, Pandas, and SQLite.

1. Open the project folder in VS Code or Jupyter Notebook.
2. Install Jupyter and the required libraries if needed:

   ```bash
   python -m pip install notebook pandas matplotlib
   ```

3. Open `Skillswap_Project.ipynb`.
4. Select **Run All** to execute the analysis cells.

Make sure the Flask project files and database are available in the project folder before running the notebook.
## Screenshots

The `screenshots/` folder contains screenshots demonstrating the main features of the SkillSwap platform:

- Home and login page
- User registration
- Student dashboard
- Add New Skill form
- Skill search and matching
- Exchange request functionality

These screenshots demonstrate the platform's user interface and core workflow.

## Project Submission Files

- `Skillswap_Project.ipynb` — Jupyter Notebook containing the project analysis, matching logic, and tests.
- `SkillSwap_Project_Report.pdf` — Project report describing the objectives, methodology, results, and limitations.
- `screenshots/` — Screenshots of the working web application.
- `README.md` — Project overview and setup instructions.

## Running the Jupyter Notebook

1. Open the project folder in VS Code.
2. Open `Skillswap_Project.ipynb`.
3. Select a Python kernel if prompted.
4. Run the notebook cells from top to bottom.

**Note:** The notebook uses project files and database data, so keep it inside the project folder.
